SELECT Nombre FROM producto;
SELECT Nombre,Precio FROM producto;
SELECT * FROM producto;
SELECT Precio_Euros,Precio,Nombre FROM Producto;



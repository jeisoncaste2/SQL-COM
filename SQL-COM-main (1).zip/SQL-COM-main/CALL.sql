CALL producto('Disco duro SATA3 1TB', 86.99, 5);
CALL producto('Memoria RAM DDR4 8GB', 120, 6);
CALL producto('Disco SSD 1 TB', 150.99, 4);
CALL producto('GeForce GTX 1050Ti', 185, 7);
CALL producto('GeForce GTX 1080 Xtreme', 755, 6);
CALL producto('Monitor 24 LED Full HD', 202, 1);
CALL producto('Monitor 27 LED Full HD', 245.99, 1);
CALL producto('Portátil Yoga 520', 559, 2);
CALL producto('Portátil Ideapd 320', 444, 2);
CALL producto('Impresora HP Deskjet 3720', 59.99, 3);
CALL producto('Impresora HP LaserJet Pro M26nw', 180, 3);
/*----------------------------------------------------------------------------*/

CALL fabricante('Asus');
CALL fabricante( 'Lenovo');
CALL fabricante( 'Hewlett-Packard');
CALL fabricante( 'Samsung');
CALL fabricante( 'Seagate');
CALL fabricante( 'Crucial');
CALL fabricante( 'Gigabyte');
CALL fabricante( 'Huawei');
CALL fabricante( 'Xiaomi');

